curl -sL https://deb.nodesource.com/setup_16.x | bash -
apt-get install -y nodejs screen vim
